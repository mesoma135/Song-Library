# Song-Library
Full-Stack music app using Node.js, Express,js, and MySQL, with RESTful CRUD APIs, real-time filtering, and a normalized relational database
